Step 1: install node.js (maybe v8.15.1)
    sudo apt-get update
    sudo apt-get install curl
    curl -sL https://deb.nodesource.com/setup_8.x | sudo -E bash -
    sudo apt-get install nodejs
    
Step 2: install express
    npm install express
    
Step 3: run nodejs server
    node code_breaker_server.js

Step 4: open the html file
    code_breaker_client.html
